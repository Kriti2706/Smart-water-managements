#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// OLED Display Configuration
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET    -1
#define SCREEN_ADDRESS 0x3C
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// Pin Definitions according to project documentation
const int PIN_TRIG        = 5;
const int PIN_ECHO        = 18;
const int PIN_RELAY       = 23;
const int PIN_BUZZER      = 13;
const int PIN_BTN_START   = 32;
const int PIN_BTN_STOP    = 33;
const int PIN_LED_RED     = 25;
const int PIN_LED_YELLOW  = 26;
const int PIN_LED_GREEN   = 27;
const int PIN_LED_BLUE    = 14;

// Tank Calibration Distance (in cm)
const float DIST_EMPTY = 100.0;
const float DIST_FULL  = 10.0;

// State Variables
bool pumpState = false;
float waterLevel = 0.0;       // Explicitly starts at 0%
String systemStatus = "IDLE";

// Timing Variables: 200 ms per 1% = 20 seconds total for 0 to 100%
unsigned long prevSimTime = 0;
const unsigned long simInterval = 200;

unsigned long prevFaultCheckTime = 0;
const unsigned long faultCheckInterval = 3000;
float levelAtLastCheck = 0.0;

void setup() {
  Serial.begin(115200);

    // Initialize GPIOs
      pinMode(PIN_TRIG, OUTPUT);
        pinMode(PIN_ECHO, INPUT);
          pinMode(PIN_RELAY, OUTPUT);
            pinMode(PIN_BUZZER, OUTPUT);

              pinMode(PIN_LED_RED, OUTPUT);
                pinMode(PIN_LED_YELLOW, OUTPUT);
                  pinMode(PIN_LED_GREEN, OUTPUT);
                    pinMode(PIN_LED_BLUE, OUTPUT);

                      pinMode(PIN_BTN_START, INPUT_PULLUP);
                        pinMode(PIN_BTN_STOP, INPUT_PULLUP);

                          // Default states
                            digitalWrite(PIN_RELAY, LOW);
                              digitalWrite(PIN_BUZZER, LOW);
                                setLEDs(0);

                                  // Initialize OLED
                                    Wire.begin(21, 22);
                                      if (!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
                                          Serial.println(F("SSD1306 allocation failed"));
                                              for (;;);
                                                }

                                                  display.clearDisplay();
                                                    display.setTextColor(SSD1306_WHITE);
                                                      display.setTextSize(1);
                                                        display.setCursor(15, 25);
                                                          display.print(F("SMART WATER SYS"));
                                                            display.display();
                                                              delay(1500);

                                                                // Start initial display at 0%
                                                                  waterLevel = 0.0;
                                                                    levelAtLastCheck = 0.0;
                                                                      updateOLED();
                                                                      }

                                                                      void loop() {
                                                                        unsigned long currentMillis = millis();

                                                                          // 1. Manual Controls
                                                                            if (digitalRead(PIN_BTN_STOP) == LOW) {
                                                                                pumpState = false;
                                                                                    digitalWrite(PIN_RELAY, LOW);
                                                                                        digitalWrite(PIN_BUZZER, LOW);
                                                                                            systemStatus = "STOPPED";
                                                                                              }

                                                                                                if (digitalRead(PIN_BTN_START) == LOW) {
                                                                                                    // If starting from full or stopped, begin filling demonstration
                                                                                                        if (waterLevel >= 100.0) {
                                                                                                              waterLevel = 0.0; // Reset back to 0% if already full
                                                                                                                  }
                                                                                                                      pumpState = true;
                                                                                                                          digitalWrite(PIN_RELAY, HIGH);
                                                                                                                              digitalWrite(PIN_BUZZER, LOW);
                                                                                                                                  systemStatus = "FILLING";
                                                                                                                                      prevFaultCheckTime = currentMillis;
                                                                                                                                          levelAtLastCheck = waterLevel;
                                                                                                                                            }

                                                                                                                                              // 2. Simulated Filling Process (0% -> 100% over 20s)
                                                                                                                                                if (pumpState) {
                                                                                                                                                    if (currentMillis - prevSimTime >= simInterval) {
                                                                                                                                                          prevSimTime = currentMillis;
                                                                                                                                                                if (waterLevel < 100.0) {
                                                                                                                                                                        waterLevel += 1.0;
                                                                                                                                                                              }
                                                                                                                                                                                  }
                                                                                                                                                                                    }

                                                                                                                                                                                      // 3. Status and Full Tank Cutoff
                                                                                                                                                                                        if (waterLevel >= 100.0) {
                                                                                                                                                                                            waterLevel = 100.0;
                                                                                                                                                                                                pumpState = false;
                                                                                                                                                                                                    digitalWrite(PIN_RELAY, LOW);
                                                                                                                                                                                                        digitalWrite(PIN_BUZZER, HIGH); // Sound alarm when 100% full
                                                                                                                                                                                                            systemStatus = "FULL";
                                                                                                                                                                                                              } else if (pumpState) {
                                                                                                                                                                                                                  if (waterLevel >= 90.0) {
                                                                                                                                                                                                                        systemStatus = "NEAR FULL";
                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                  systemStatus = "FILLING";
                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                        }

                                                                                                                                                                                                                                          // 4. Fault Detection Logic
                                                                                                                                                                                                                                            if (currentMillis - prevFaultCheckTime >= faultCheckInterval) {
                                                                                                                                                                                                                                                if (pumpState) {
                                                                                                                                                                                                                                                      if (waterLevel <= levelAtLastCheck) {
                                                                                                                                                                                                                                                              pumpState = false;
                                                                                                                                                                                                                                                                      digitalWrite(PIN_RELAY, LOW);
                                                                                                                                                                                                                                                                              digitalWrite(PIN_BUZZER, HIGH);
                                                                                                                                                                                                                                                                                      systemStatus = "FILL FAILURE";
                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                } else if (systemStatus != "STOPPED" && systemStatus != "FULL") {
                                                                                                                                                                                                                                                                                                      if (levelAtLastCheck - waterLevel > 2.0) {
                                                                                                                                                                                                                                                                                                              systemStatus = "POSSIBLE LEAK";
                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                            levelAtLastCheck = waterLevel;
                                                                                                                                                                                                                                                                                                                                prevFaultCheckTime = currentMillis;
                                                                                                                                                                                                                                                                                                                                  }

                                                                                                                                                                                                                                                                                                                                    // 5. Update Status Indications
                                                                                                                                                                                                                                                                                                                                      setLEDs(waterLevel);
                                                                                                                                                                                                                                                                                                                                        updateOLED();
                                                                                                                                                                                                                                                                                                                                        }

                                                                                                                                                                                                                                                                                                                                        // Control 4-level LED indication (0-25% Red, 26-50% Yellow, 51-75% Green, 76-100% Blue)
                                                                                                                                                                                                                                                                                                                                        void setLEDs(float level) {
                                                                                                                                                                                                                                                                                                                                          digitalWrite(PIN_LED_RED,    (level > 0.0  && level <= 25.0) ? HIGH : LOW);
                                                                                                                                                                                                                                                                                                                                            digitalWrite(PIN_LED_YELLOW, (level > 25.0 && level <= 50.0) ? HIGH : LOW);
                                                                                                                                                                                                                                                                                                                                              digitalWrite(PIN_LED_GREEN,  (level > 50.0 && level <= 75.0) ? HIGH : LOW);
                                                                                                                                                                                                                                                                                                                                                digitalWrite(PIN_LED_BLUE,   (level > 75.0)                  ? HIGH : LOW);
                                                                                                                                                                                                                                                                                                                                                }

                                                                                                                                                                                                                                                                                                                                                // Render interface on SSD1306 OLED
                                                                                                                                                                                                                                                                                                                                                void updateOLED() {
                                                                                                                                                                                                                                                                                                                                                  display.clearDisplay();
                                                                                                                                                                                                                                                                                                                                                    display.setTextColor(SSD1306_WHITE);

                                                                                                                                                                                                                                                                                                                                                      display.setTextSize(1);
                                                                                                                                                                                                                                                                                                                                                        display.setCursor(0, 0);
                                                                                                                                                                                                                                                                                                                                                          display.print(F("WATER LEVEL: "));
                                                                                                                                                                                                                                                                                                                                                            display.print((int)waterLevel);
                                                                                                                                                                                                                                                                                                                                                              display.print(F("%"));

                                                                                                                                                                                                                                                                                                                                                                // Progress Bar
                                                                                                                                                                                                                                                                                                                                                                  display.drawRect(0, 14, 128, 10, SSD1306_WHITE);
                                                                                                                                                                                                                                                                                                                                                                    int fillWidth = map((int)waterLevel, 0, 100, 0, 124);
                                                                                                                                                                                                                                                                                                                                                                      display.fillRect(2, 16, fillWidth, 6, SSD1306_WHITE);

                                                                                                                                                                                                                                                                                                                                                                        display.setCursor(0, 32);
                                                                                                                                                                                                                                                                                                                                                                          display.print(F("PUMP   : "));
                                                                                                                                                                                                                                                                                                                                                                            display.print(pumpState ? F("ON") : F("OFF"));

                                                                                                                                                                                                                                                                                                                                                                              display.setCursor(0, 48);
                                                                                                                                                                                                                                                                                                                                                                                display.print(F("STATUS : "));
                                                                                                                                                                                                                                                                                                                                                                                  display.print(systemStatus);

                                                                                                                                                                                                                                                                                                                                                                                    display.display();
                                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                                    